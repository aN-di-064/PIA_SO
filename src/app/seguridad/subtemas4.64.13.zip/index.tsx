import { Link } from "expo-router";
import { SafeAreaView, ScrollView, Text, View } from "react-native";
import { styles } from "../../styles/index.styles";

const subtemasSeguridad = [
  { id: "seguridadConexiones", title: "Seguridad de las conexiones" },
  { id: "seguridadConexionesDetalle", title: "Seguridad de las conexiones" },
  { id: "mecanismosChromeOS", title: "Mecanismos de seguridad de ChromeOS" },
  { id: "perdidaRobo", title: "Seguridad del dispositivo frente a pérdida o robo" },
  { id: "nivelesSeguridad", title: "Niveles de seguridad según el entorno" },
  { id: "prevencionRiesgos", title: "Prevención y administración de riesgos" },
  { id: "limitacionesSeguridad", title: "Problemas y limitaciones de seguridad" },
  { id: "buenasPracticas", title: "Soluciones y buenas prácticas" },
] as const;

export default function SeguridadIndexScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text style={styles.title}>Redes y Seguridad</Text>
        </View>

        <View style={styles.hubContainer}>
          {subtemasSeguridad.map((item) => (
            <Link
              key={item.id}
              href={`/seguridad/${item.id}` as any}
              style={styles.topicCard}
            >
              <Text style={styles.cardTitle}>{item.title}</Text>
            </Link>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
